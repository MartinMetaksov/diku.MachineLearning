main.py is the main file, containing main tests
the core package contains my implementation of k-NN and Linear Regression algorithms used for mutating the data
the tests package contain further tests, which have been used to verify the correctness of the core libraries